execute unless block 0 200 0 minecraft:polished_blackstone run fill -4 200 -4 4 200 4 minecraft:polished_blackstone
execute unless block 0 201 0 minecraft:glass run fill -4 201 -4 4 204 4 minecraft:glass hollow
fill -4 201 -4 -4 204 -4 minecraft:sea_lantern
fill 4 201 -4 4 204 -4 minecraft:sea_lantern
fill -4 201 4 -4 204 4 minecraft:sea_lantern
fill 4 201 4 4 204 4 minecraft:sea_lantern
setblock 0 204 0 minecraft:sea_lantern
