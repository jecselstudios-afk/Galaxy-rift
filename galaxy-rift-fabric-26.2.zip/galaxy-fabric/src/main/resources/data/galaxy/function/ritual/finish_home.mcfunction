execute as @a[distance=..64] run function galaxy:warp/home
