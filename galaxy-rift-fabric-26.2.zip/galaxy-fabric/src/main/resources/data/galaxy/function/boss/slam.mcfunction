execute as @e[distance=..8,type=!galaxy:galaxy_warden,type=!galaxy:void_stalker,type=!minecraft:item,type=!minecraft:marker] run damage @s 12 minecraft:magic
particle minecraft:reverse_portal ~ ~0.5 ~ 4 0.5 4 0.3 120 force
playsound minecraft:entity.ender_dragon.growl hostile @a ~ ~ ~ 2 1.4
