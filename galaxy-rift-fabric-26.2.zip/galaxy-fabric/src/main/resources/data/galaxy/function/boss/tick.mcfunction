scoreboard players add @s galaxy_t 1
execute store result bossbar galaxy:warden value run data get entity @s Health 1
bossbar set galaxy:warden players @a[distance=..80]
scoreboard players operation #b galaxy_t = @s galaxy_t
scoreboard players operation #b galaxy_t %= #160 galaxy_t
execute if score #b galaxy_t matches 0 if entity @p[distance=..40] run function galaxy:boss/summon
scoreboard players operation #s galaxy_t = @s galaxy_t
scoreboard players operation #s galaxy_t %= #100 galaxy_t
execute if score #s galaxy_t matches 0 if entity @p[distance=..8] run function galaxy:boss/slam
