execute as @e[type=minecraft:marker,tag=galaxy_ritual] at @s run function galaxy:ritual/tick
execute as @a[scores={galaxy_w=1..}] at @s run function galaxy:warp/tick
execute as @e[type=galaxy:galaxy_warden] at @s run function galaxy:boss/tick
execute in galaxy:starfall unless entity @e[type=galaxy:galaxy_warden] run bossbar set galaxy:warden players
execute as @a at @s if items entity @s armor.head galaxy:starforged_helmet if items entity @s armor.chest galaxy:starforged_chestplate if items entity @s armor.legs galaxy:starforged_leggings if items entity @s armor.feet galaxy:starforged_boots run function galaxy:armor/bonus
