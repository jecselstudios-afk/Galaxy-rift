effect give @s minecraft:speed 3 1 true
effect give @s minecraft:strength 3 2 true
effect give @s minecraft:resistance 3 2 true
effect give @s minecraft:regeneration 3 1 true
effect give @s minecraft:health_boost 3 4 true
effect give @s minecraft:jump_boost 3 1 true
effect give @s minecraft:fire_resistance 3 0 true
effect give @s minecraft:water_breathing 3 0 true
effect give @s minecraft:night_vision 13 0 true
advancement grant @s only galaxy:cosmic_knight
