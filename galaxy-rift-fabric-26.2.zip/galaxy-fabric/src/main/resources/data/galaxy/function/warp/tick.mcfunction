scoreboard players remove @s galaxy_w 1
function galaxy:warp/streaks
execute if score @s galaxy_w matches 0 run function galaxy:warp/land
