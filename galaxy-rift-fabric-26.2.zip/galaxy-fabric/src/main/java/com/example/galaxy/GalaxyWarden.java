package com.example.galaxy;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.level.Level;

/** Boss of Starfall. Its boss bar, minion summons and ground slam live in data/galaxy/function/boss/. */
public class GalaxyWarden extends Zombie {
	public GalaxyWarden(EntityType<? extends Zombie> type, Level level) {
		super(type, level);
	}

	public static AttributeSupplier.Builder attributes() {
		return Zombie.createAttributes()
				.add(Attributes.MAX_HEALTH, 500.0)
				.add(Attributes.ATTACK_DAMAGE, 16.0)
				.add(Attributes.MOVEMENT_SPEED, 0.28)
				.add(Attributes.ARMOR, 20.0)
				.add(Attributes.FOLLOW_RANGE, 64.0)
				.add(Attributes.KNOCKBACK_RESISTANCE, 0.9)
				.add(Attributes.SCALE, 2.0);
	}
}
