package com.example.galaxy;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityType;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.level.levelgen.Heightmap;

public class ModEntities {
	public static final ResourceKey<EntityType<?>> VOID_STALKER_KEY = ResourceKey.create(Registries.ENTITY_TYPE, GalaxyMod.id("void_stalker"));
	public static final ResourceKey<EntityType<?>> GALAXY_WARDEN_KEY = ResourceKey.create(Registries.ENTITY_TYPE, GalaxyMod.id("galaxy_warden"));

	public static final EntityType<Zombie> VOID_STALKER = Registry.register(BuiltInRegistries.ENTITY_TYPE, VOID_STALKER_KEY,
			FabricEntityType.Builder.<Zombie>createMob(VoidStalker::new, MobCategory.MONSTER, mob -> mob
							.spawnPlacement(SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mob::checkMobSpawnRules)
							.defaultAttributes(VoidStalker::attributes))
					.sized(0.6F, 1.95F)
					.clientTrackingRange(8)
					.build(VOID_STALKER_KEY));

	public static final EntityType<Zombie> GALAXY_WARDEN = Registry.register(BuiltInRegistries.ENTITY_TYPE, GALAXY_WARDEN_KEY,
			FabricEntityType.Builder.<Zombie>createMob(GalaxyWarden::new, MobCategory.MONSTER, mob -> mob
							.defaultAttributes(GalaxyWarden::attributes))
					.sized(0.6F, 1.95F)
					.clientTrackingRange(10)
					.fireImmune()
					.build(GALAXY_WARDEN_KEY));

	public static void init() {
		// touching this class registers everything above
	}
}
