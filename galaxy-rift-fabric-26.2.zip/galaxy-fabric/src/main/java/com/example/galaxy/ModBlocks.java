package com.example.galaxy;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;

public class ModBlocks {
	public static final ResourceKey<Block> RIFT_CORE_KEY = ResourceKey.create(Registries.BLOCK, GalaxyMod.id("rift_core"));
	public static final ResourceKey<Item> RIFT_CORE_ITEM_KEY = ResourceKey.create(Registries.ITEM, GalaxyMod.id("rift_core"));

	public static final Block RIFT_CORE = Registry.register(BuiltInRegistries.BLOCK, RIFT_CORE_KEY,
			new Block(BlockBehaviour.Properties.of()
					.mapColor(MapColor.COLOR_PURPLE)
					.strength(30.0F, 1200.0F)
					.sound(SoundType.STONE)
					.lightLevel(state -> 15)
					.setId(RIFT_CORE_KEY)));

	public static final Item RIFT_CORE_ITEM = Registry.register(BuiltInRegistries.ITEM, RIFT_CORE_ITEM_KEY,
			new BlockItem(RIFT_CORE, new Item.Properties().useBlockDescriptionPrefix().rarity(Rarity.EPIC).setId(RIFT_CORE_ITEM_KEY)));

	public static void init() {
		// touching this class registers everything above
	}
}
