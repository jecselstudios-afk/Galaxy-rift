package com.example.galaxy;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.level.Level;

/** A much tougher zombie that lives in the Starfall dimension. Hits inflict Wither (see CombatEvents). */
public class VoidStalker extends Zombie {
	public VoidStalker(EntityType<? extends Zombie> type, Level level) {
		super(type, level);
	}

	public static AttributeSupplier.Builder attributes() {
		return Zombie.createAttributes()
				.add(Attributes.MAX_HEALTH, 70.0)
				.add(Attributes.ATTACK_DAMAGE, 12.0)
				.add(Attributes.MOVEMENT_SPEED, 0.30)
				.add(Attributes.ARMOR, 12.0)
				.add(Attributes.FOLLOW_RANGE, 40.0)
				.add(Attributes.KNOCKBACK_RESISTANCE, 0.4);
	}
}
