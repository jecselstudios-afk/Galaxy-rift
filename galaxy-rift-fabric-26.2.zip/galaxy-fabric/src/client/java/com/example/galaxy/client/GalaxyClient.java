package com.example.galaxy.client;

import com.example.galaxy.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.renderer.entity.ZombieRenderer;
import net.minecraft.world.entity.monster.zombie.Zombie;

public class GalaxyClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// Both mobs borrow the vanilla zombie model for now (custom skins/models: phase 2).
		EntityRendererRegistry.<Zombie>register(ModEntities.VOID_STALKER, ZombieRenderer::new);
		EntityRendererRegistry.<Zombie>register(ModEntities.GALAXY_WARDEN, ZombieRenderer::new);
	}
}
